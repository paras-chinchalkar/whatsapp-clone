const mongoose = require('mongoose');
const chat = require('./models/chats'); // Make sure the schema is correctly set up

let allchats = [
    {
        from: 'a',
        to: 'b',
        msg: 'lirililarila',
        created_at: new Date(),
    },
    {
        from: 'a',
        to: 'b',
        msg: 'bombardino crocodilo',
        created_at: new Date(),
    },
    {
        from: 'a',
        to: 'b',
        msg: 'balerina capuchina mimimimi elamule decapuchina assisina',
        created_at: new Date(), // Consider adding 'created_at' here as well for consistency
    },
    {
        from: 'c',
        to: 'd',
        msg: 'bombambini guisini',
        created_at: new Date(),
    },
];

async function main() {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/whatsapp');
        console.log('Connection successful');

        // Insert chats into the database
        await chat.insertMany(allchats);
        console.log('Chats inserted successfully');
    } catch (err) {
        console.error('Error:', err);
    } finally {
        mongoose.connection.close(); // Close the connection when done
    }
}

main();
