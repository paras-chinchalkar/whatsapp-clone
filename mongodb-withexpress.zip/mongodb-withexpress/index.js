// VERY BASIC SETUP
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const path = require('path');
const chat = require('./models/chats.js');
const methodOverride = require('method-override');

const PORT = 8080; // Define the PORT variable

// Views configuration
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware for serving static files and parsing request body
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method')); // Middleware to support PUT/DELETE in forms

// Connecting to the database
async function main() {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/whatsapp');
        console.log('Database connection successful');
    } catch (err) {
        console.error('Database connection error:', err);
    }
}
main(); // Start the database connection

// Route to display all chats
app.get('/chats', async (req, res) => {
    try {
        const chats = await chat.find(); // Fetch all chats from the database
        res.render('index.ejs', { chats }); // Render the index.ejs template with chat data
    } catch (err) {
        console.error('Error fetching chats:', err);
        res.status(500).send('Error retrieving chats');
    }
});

// Route to edit a specific chat
app.get('/chats/:id/edit', async (req, res) => {
    const id = req.params.id.trim(); // Clean up spaces
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).send('Invalid Chat ID'); // Handle invalid ID
    }
    try {
        const chatData = await chat.findById(id); // Fetch chat from database
        if (!chatData) {
            return res.status(404).send('Chat not found'); // Handle non-existent chat
        }
        res.render('edit.ejs', { chatData }); // Pass the chat data to the view
    } catch (err) {
        console.error('Error fetching chat:', err);
        res.status(500).send('Error retrieving the chat');
    }
});

// Route to handle updating a chat
app.put('/chats/:id', async (req, res) => {
    const { id } = req.params; // Extract chat ID
    const { msg } = req.body; // Extract updated message from request body

    try {
        const updatedChat = await chat.findByIdAndUpdate(
            id,
            { msg }, // Update only the message
            { runValidators: true, new: true } // Enforce validation and return the updated document
        );
        if (!updatedChat) {
            return res.status(404).send('Chat not found');
        }
        console.log('Chat updated successfully:', updatedChat);
        res.redirect('/chats'); // Redirect to the chats list
    } catch (err) {
        console.error('Error updating chat:', err);
        res.status(500).send('Error updating chat');
    }
});

// Delete Route
app.delete('/chats/:id', async (req, res) => {
    const { id } = req.params; // Extract chat ID
    if (!mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).send('Invalid Chat ID');
    }
    try {
        const chatToBeDeleted = await chat.findByIdAndDelete(id);
        if (!chatToBeDeleted) {
            return res.status(404).send('Chat not found');
        }
        console.log('Chat deleted successfully:', chatToBeDeleted);
        res.redirect('/chats'); // Redirect to the chats list after deletion
    } catch (err) {
        console.error('Error deleting chat:', err);
        res.status(500).send('Error deleting chat');
    }
});

// Route to render the new chat creation form
app.get('/chats/new', (req, res) => {
    res.render('new.ejs'); // Render the new.ejs template
});

// Route to handle the creation of a new chat
app.post('/chats', async (req, res) => {
    const { from, to, msg } = req.body; // Extract data from the request body
    const newChat = new chat({
        from,
        to,
        msg,
        created_at: new Date(),
    });

    try {
        await newChat.save(); // Save the new chat to the database
        console.log('Chat saved successfully:', newChat);
        res.redirect('/chats'); // Redirect to the chats list
    } catch (err) {
        console.error('Error saving chat:', err);
        res.status(500).send('Error creating chat');
    }
});

// Basic home route
app.get('/', (req, res) => {
    res.send('The response is working fine'); // Send a basic response
});

// Starting the server
app.listen(PORT, () => {
    console.log(`Server is listening on ${PORT}`);
});